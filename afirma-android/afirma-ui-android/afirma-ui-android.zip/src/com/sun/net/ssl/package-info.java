/** Clases <code>com.sun</code> no existentes en Android, vac&iacute;as en implementac&iacute;n,
 * solo para habilitar la compilaci&oacute;n.
 * @author Tom&aacute;s Garc&iacute;a-Mer&aacute;s */
package com.sun.net.ssl;