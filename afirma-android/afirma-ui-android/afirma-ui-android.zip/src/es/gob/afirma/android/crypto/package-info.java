/** Clases espec&iacute;ficas de criptograf&iacute;a en Google Android.
 * @author Tom&aacute;s Garc&iacute;a-Mer&aacute;s */
package es.gob.afirma.android.crypto;